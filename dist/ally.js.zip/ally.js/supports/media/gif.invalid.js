'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ';
module.exports = exports['default'];
//# sourceMappingURL=gif.invalid.js.map