
// this file is overwritten by `npm run build:pre`
const version = '1.4.1';
export default version;
