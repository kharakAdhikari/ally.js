
// export default 'data:audio/mp3;base64,audio-focus-test';
import gif from './gif';
export default gif;
