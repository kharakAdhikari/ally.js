
// exporting modules to be included the UMD bundle

import interactionType from './interaction-type';
import shadowMutations from './shadow-mutations';
export default {
  interactionType,
  shadowMutations,
};
