'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

// this file is overwritten by `npm run build:pre`
var version = '1.4.1';
exports.default = version;
module.exports = exports['default'];
//# sourceMappingURL=version.js.map