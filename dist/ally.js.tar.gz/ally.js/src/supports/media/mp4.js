
// export default 'data:video/mp4;base64,video-focus-test';
import gif from './gif';
export default gif;
