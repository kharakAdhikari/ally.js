
// exporting modules to be included the UMD bundle

import attribute from './attribute';
import keycode from './keycode';
export default {
  attribute,
  keycode,
};
