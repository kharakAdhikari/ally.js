'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _gif = require('./gif');

var _gif2 = _interopRequireDefault(_gif);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _gif2.default;
// export default 'data:video/mp4;base64,video-focus-test';

module.exports = exports['default'];
//# sourceMappingURL=mp4.js.map